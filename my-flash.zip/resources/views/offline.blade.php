<x-guest-layout>
    <h1>You are currently not connected to any networks.</h1>
</x-guest-layout>
